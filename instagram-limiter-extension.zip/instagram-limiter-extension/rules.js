[
  {
    id: 1,
    priority: 1,
    action: {
      type: "allow",
    },
    condition: {
      urlFilter: "https://www.instagram.com/accounts/login/",
      resourceTypes: ["main_frame"],
    },
  },
  {
    id: 2,
    priority: 1,
    action: {
      type: "allow",
    },
    condition: {
      urlFilter: "https://www.snapchat.com/login/",
      resourceTypes: ["main_frame"],
    },
  },
];
